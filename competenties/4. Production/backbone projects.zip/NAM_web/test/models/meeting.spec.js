/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Meeting Model', function () {

    beforeEach(function () {
        this.MeetingModel = new App.Models.Meeting();
    });

});
