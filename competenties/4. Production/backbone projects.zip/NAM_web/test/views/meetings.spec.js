/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Meetings View', function () {

    beforeEach(function () {
        this.MeetingsView = new App.Views.Meetings();
    });

});
