/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Subjects View', function () {

    beforeEach(function () {
        this.SubjectsView = new App.Views.Subjects();
    });

});
