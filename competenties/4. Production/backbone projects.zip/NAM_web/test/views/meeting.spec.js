/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Meeting View', function () {

    beforeEach(function () {
        this.MeetingView = new App.Views.Meeting();
    });

});
