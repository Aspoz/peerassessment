/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Meeting Collection', function () {

    beforeEach(function () {
        this.MeetingCollection = new App.Collections.Meeting();
    });

});
