/*global App, Backbone*/

App.Routers = App.Routers || {};

(function () {
    'use strict';

    App.Routers.Main = Backbone.Router.extend({
      routes: {
        '': 'index',
        'meetings': 'index',
        'meetings/new': 'newMeeting',
        'meetings/:id': 'showSubjects',
        'meetings/:id/edit': 'editMeeting'
      },

      index: function() {
        var v = new App.Views.Meetings({collection: new App.Collections.Meeting()});
        $('#js-app').html(v.render().el);
      },

      showSubjects: function(id) {
        App.Vent.trigger('subjects:index', id);

        var v = new App.Views.Subjects({model: new App.Models.Meeting({ id: id })});
        $('#js-app').html(v.render().el);
      }
    });

})();
