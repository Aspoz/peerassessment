/*global App, Backbone*/

App.Collections = App.Collections || {};

(function () {
    'use strict';

    App.Collections.Meeting = Backbone.Collection.extend({

        model: App.Models.Meeting,
        url: 'http://0.0.0.0:3000/meetings'

    });

})();
