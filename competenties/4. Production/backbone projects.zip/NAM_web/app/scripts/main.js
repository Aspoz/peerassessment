/*global App, $*/


window.App = {
    Models: {},
    Collections: {},
    Views: {},
    Routers: {},
    Vent: _.extend({}, Backbone.Events),
    init: function () {
        'use strict';
        new App.Routers.Main()
        // Backbone.history.start({pushState: true});
        Backbone.history.start();
    }
};

$(document).ready(function () {
    'use strict';
    App.init();
});
