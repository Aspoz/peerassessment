/*global App, Backbone, JST*/

App.Views = App.Views || {};

(function () {
    'use strict';

    App.Views.Meetings = Backbone.View.extend({

        template: JST['app/scripts/templates/meetings.hbs'],

        tagName: 'div',

        id: '',

        className: '',

        events: { },

        initialize: function () {
            this.listenTo(this.collection, 'reset', this.render);
            this.collection.fetch({ reset: true })
        },

        render: function () {
            var t = this;
            this.$el.html(this.template());
            this.collection.forEach(function(model) {
                t.renderMeeting(model);
            });
            return this;
        },

        renderMeeting: function(model) {
            var v = new App.Views.Meeting({model: model});
            this.$el.append(v.render().el);
        },

        gotomeeting: function() {
            Backbone.history.navigate('meetings', {trigger: true});
        }

    });

})();
