/*global App, Backbone, JST*/

App.Views = App.Views || {};

(function () {
    'use strict';

    App.Views.Meeting = Backbone.View.extend({

        template: JST['app/scripts/templates/meeting.hbs'],

        tagName: 'div',

        id: '',

        className: '',

        events: {
            'dblclick': 'gotoSubjects'
        },

        initialize: function () {
            this.listenTo(this.model, 'change', this.render);
        },

        render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        },

        gotoSubjects: function() {
            var id = this.model.get('id');
            Backbone.history.navigate('meetings/'+id, {trigger: true});
        }

    });

})();
