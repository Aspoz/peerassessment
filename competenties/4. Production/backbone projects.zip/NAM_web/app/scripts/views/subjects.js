/*global App, Backbone, JST*/

App.Views = App.Views || {};

(function () {
    'use strict';

    App.Views.Subjects = Backbone.View.extend({

        template: JST['app/scripts/templates/subjects.hbs'],

        tagName: 'div',

        id: '',

        className: '',

        events: {
        },

        initialize: function () {
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.model, 'sync', this.render);
            this.model.fetch();
        },

        render: function () {
            window.model = this.model;
            this.$el.html(this.template(this.model.toJSON()));

            var subjects = this.model.get('subjects');

            _.map(subjects,function(subject) {
                console.log(subject.id);
                return subject;
            })
            return this;
        }

    });

})();
