# Instructies

**Helaas is het niet mogelijk om te testen aangezien hij de api uit `https://github.com/Aspoz/apivoortesten` gebruikt. Maar mog je deze runnen dan zou je het eventueel wel kunnen testen**

Om de server te starten moet je eerst alle packages downloaden. Dit doe je door `npm install && bower install` uit te voeren. Als dit eenmaal klaar is voer je `grunt serve` uit.