/*global App, Backbone*/

App.Collections = App.Collections || {};

(function () {
    'use strict';

    App.Collections.Document = Backbone.Collection.extend({

        model: App.Models.Document,
        url: App.api_root + 'documents'

    });

})();
