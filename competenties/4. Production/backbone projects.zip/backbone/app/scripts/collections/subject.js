/*global App, Backbone*/

App.Collections = App.Collections || {};

(function () {
    'use strict';

    App.Collections.Subject = Backbone.Collection.extend({

        model: App.Models.Subject,
        url: App.api_root + 'subjects'

    });

})();
