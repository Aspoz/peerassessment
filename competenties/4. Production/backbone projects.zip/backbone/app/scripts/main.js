/*global App, $*/


window.App = {
    Models: {},
    Collections: {},
    Views: {},
    Routers: {},
    api_root: 'http://localhost:3000/',
    init: function () {
        'use strict';
        new App.Routers.Main()
        Backbone.history.start();
    }
};

$(document).ready(function () {
    'use strict';
    App.init();
});
