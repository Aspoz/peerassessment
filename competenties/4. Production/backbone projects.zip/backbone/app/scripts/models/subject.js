/*global App, Backbone*/

App.Models = App.Models || {};

(function () {
    'use strict';

    App.Models.Subject = Backbone.RelationalModel.extend({

        urlRoot: App.api_root + 'subjects',
        idAttribute: 'id',

        relations: [{
            type: Backbone.HasMany,
            key: 'documents',
            relatedModel: 'App.Models.Document',
            collectionType: 'App.Collections.Document',
            reverseRelation: {
                key: 'inSubject',
                includeInJSON: 'id'
            },
        }],

        initialize: function() {
        },

        defaults: {
            'id': '',
            'title': ''
        },

        validate: function(attrs, options) {
        },

        parse: function(response, options)  {
            return response;
        }
    });

})();
