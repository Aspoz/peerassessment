/*global App, Backbone*/

App.Models = App.Models || {};

(function () {
    'use strict';

    App.Models.Document = Backbone.RelationalModel.extend({

        urlRoot: App.api_root + 'documents',
        idAttribute: 'id',

        initialize: function() {
        },

        defaults: {
            'id': '',
            'title': ''
        },

        validate: function(attrs, options) {
        },

        parse: function(response, options)  {
            return response;
        }
    });

})();
