/*global App, Backbone*/

App.Routers = App.Routers || {};

(function () {
    'use strict';

    App.Routers.Main = Backbone.Router.extend({
        routes: {
            '': 'show_subject_list',
            'subjects/:id': 'show_subject'
        },

        show_subject_list: function() {
            var c = new App.Collections.Subject();
            var v = new App.Views.SubjectList({collection: c});
            c.fetch().done(function() {
                $('#js-app').html(v.render().el);
            })
        },

        show_subject: function(id) {
            var m = App.Models.Subject.findOrCreate({id: id})
            var v = new App.Views.Subject({model: m})
            m.fetch().done(function() {
                $('#js-app').html(v.render().el);
            })
        }
    });

})();
