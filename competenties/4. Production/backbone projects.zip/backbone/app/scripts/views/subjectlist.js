/*global App, Backbone, JST*/

App.Views = App.Views || {};

(function () {
    'use strict';

    App.Views.SubjectList = Backbone.View.extend({

        template: JST['app/scripts/templates/subjectlist.ejs'],

        tagName: 'div',

        id: '',

        className: '',

        events: {},

        initialize: function () {
            this.listenTo(this.collection, 'change', this.render);
        },

        render: function () {
            console.log(this.collection.toJSON());
            this.$el.html(this.template());
            return this;
        }

    });

})();
