/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Main Router', function () {

    beforeEach(function () {
        this.MainRouter = new App.Routers.Main();
    });

    it('index route', function(){

    });

});
