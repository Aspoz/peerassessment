/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Subject Collection', function () {

    beforeEach(function () {
        this.SubjectCollection = new App.Collections.Subject();
    });

});
