/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Document Collection', function () {

    beforeEach(function () {
        this.DocumentCollection = new App.Collections.Document();
    });

});
