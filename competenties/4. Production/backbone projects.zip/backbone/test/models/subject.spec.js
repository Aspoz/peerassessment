/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Subject Model', function () {

    beforeEach(function () {
        this.SubjectModel = new App.Models.Subject();
    });

});
