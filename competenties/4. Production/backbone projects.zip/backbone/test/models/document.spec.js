/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Document Model', function () {

    beforeEach(function () {
        this.DocumentModel = new App.Models.Document();
    });

});
