/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('Subject View', function () {

    beforeEach(function () {
        this.SubjectView = new App.Views.Subject();
    });

});
