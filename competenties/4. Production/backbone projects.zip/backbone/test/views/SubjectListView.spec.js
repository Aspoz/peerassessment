/*global beforeEach, describe, it, assert, expect  */
'use strict';

describe('SubjectListView View', function () {

    beforeEach(function () {
        this.SubjectListViewView = new App.Views.SubjectListView();
    });

});
