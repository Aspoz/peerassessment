this["JST"] = this["JST"] || {};

this["JST"]["app/scripts/templates/subject.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<p>Subject.</p>\n\n';

}
return __p
};

this["JST"]["app/scripts/templates/subjectlist.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<p>SubjectList.</p>\n\n';

}
return __p
};